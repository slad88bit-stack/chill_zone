@echo off
title chill zone launcher
cd /d "%~dp0"

if "%PORT%"=="" set PORT=3000

rem --- check Node.js ---
where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js not found. Install it from https://nodejs.org and run again.
  pause
  exit /b 1
)

rem --- install dependencies ---
if not exist node_modules (
  echo [*] Installing dependencies...
  call npm install
)

rem --- start game server in a separate window ---
echo [*] Starting chill zone server on port %PORT%...
start "chill zone server" cmd /k node server.js

echo [*] Local game: http://localhost:%PORT%
echo.

rem --- local mode, no tunnel ---
if /i "%~1"=="--local" (
  echo [*] Local mode. Server is running in the other window.
  pause
  exit /b 0
)

rem --- check ssh (built into Windows 10/11) ---
where ssh >nul 2>nul
if errorlevel 1 (
  echo [!] ssh not found - skipping tunnel. Play locally: http://localhost:%PORT%
  pause
  exit /b 0
)

rem --- Serveo tunnel: public link will appear below ---
echo [*] Starting Serveo tunnel... public link will appear below.
echo     Press Ctrl+C or close this window to stop the tunnel.
echo     Close the "chill zone server" window to stop the server.
echo.
ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -o ExitOnForwardFailure=yes -R 80:localhost:%PORT% serveo.net

echo.
echo [*] Tunnel closed. Remember to close the "chill zone server" window.
pause
