const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const path = require('path');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// --- состояние мира ---
const WORLD = { width: 2048, height: 2048 }; // пиксели мира
const POOL = { x: 1120, y: 960, w: 256, h: 160 }; // бассейн
const players = new Map(); // id -> {x, y, dir, moving, name, skin}

let nextId = 1;

const SKINS = 6; // количество вариантов расцветки персонажа

function broadcast(obj, exceptWs) {
  const msg = JSON.stringify(obj);
  for (const client of wss.clients) {
    if (client.readyState === 1 && client !== exceptWs) client.send(msg);
  }
}

wss.on('connection', (ws) => {
  const id = nextId++;
  const player = {
    id,
    x: WORLD.width / 2 + (Math.random() * 200 - 100),
    y: WORLD.height / 2 + (Math.random() * 200 - 100),
    dir: 'down',
    moving: false,
    name: 'chiller_' + id,
    skin: Math.floor(Math.random() * SKINS),
    skinData: '',
    seat: -1,
    dance: false,
  };
  players.set(id, player);
  ws._playerId = id;

  // приветствие: твой id, мир, все игроки
  ws.send(JSON.stringify({
    t: 'welcome',
    id,
    world: WORLD,
    pool: POOL,
    players: [...players.values()],
  }));

  // сообщаем остальным
  broadcast({ t: 'join', player }, ws);

  ws.on('message', (data) => {
    let msg;
    try { msg = JSON.parse(data); } catch { return; }

    if (msg.t === 'move') {
      const p = players.get(id);
      if (!p) return;
      // простая валидация
      p.x = Math.max(0, Math.min(WORLD.width, +msg.x || 0));
      p.y = Math.max(0, Math.min(WORLD.height, +msg.y || 0));
      p.dir = ['up', 'down', 'left', 'right'].includes(msg.dir) ? msg.dir : p.dir;
      p.moving = !!msg.moving;
      p.seat = Number.isFinite(+msg.seat) ? Math.max(-1, Math.min(999, msg.seat | 0)) : -1;
      p.dance = !!msg.dance;
      p.fishing = Math.max(0, Math.min(2, msg.fishing | 0));
      p.veh = Math.max(0, Math.min(2, msg.veh | 0));
    } else if (msg.t === 'name') {
      const p = players.get(id);
      if (!p) return;
      const clean = String(msg.name || '').replace(/[\n\r\t]/g, ' ').trim().slice(0, 16);
      if (!clean) return;
      p.name = clean;
      broadcast({ t: 'name', id, name: p.name });
    } else if (msg.t === 'jump') {
      // ретранслируем прыжок остальным (big — с трамплина)
      broadcast({ t: 'jump', id, big: !!msg.big }, ws);
    } else if (msg.t === 'skin') {
      const p = players.get(id);
      if (!p) return;
      const d = String(msg.d || '');
      if (d !== '' && !/^([0-9a-f]{192}|[0-9a-f]{768})$/.test(d)) return;
      p.skinData = d;
      broadcast({ t: 'skin', id, d });
    } else if (msg.t === 'emote') {
      const e = msg.e | 0;
      if (e < 0 || e > 4) return;
      const now = Date.now();
      if (ws._lastEmote && now - ws._lastEmote < 300) return;
      ws._lastEmote = now;
      broadcast({ t: 'emote', id, e }, ws);
    } else if (msg.t === 'chat') {
      const p = players.get(id);
      if (!p) return;
      // антиспам: не чаще 2 сообщений в секунду
      const now = Date.now();
      if (ws._lastChat && now - ws._lastChat < 500) return;
      ws._lastChat = now;
      const text = String(msg.text || '').replace(/[\n\r]/g, ' ').trim().slice(0, 120);
      if (!text) return;
      broadcast({ t: 'chat', id, name: p.name, text });
    }
  });

  ws.on('close', () => {
    players.delete(id);
    broadcast({ t: 'leave', id });
  });
});

// рассылка состояния 15 раз в секунду
setInterval(() => {
  if (players.size === 0) return;
  broadcast({
    t: 'state',
    players: [...players.values()].map(p => ({
      id: p.id, x: Math.round(p.x), y: Math.round(p.y),
      dir: p.dir, moving: p.moving, name: p.name, skin: p.skin,
      seat: p.seat, dance: p.dance, fishing: p.fishing || 0, veh: p.veh || 0,
    })),
  });
}, 1000 / 15);

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log('chill zone server on :' + PORT);
});
