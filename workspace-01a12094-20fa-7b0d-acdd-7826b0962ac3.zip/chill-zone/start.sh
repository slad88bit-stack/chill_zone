#!/usr/bin/env bash
# ============================================
#  CHILL ZONE — запуск сервера + туннель Serveo
#  Использование:  ./start.sh            (сервер + публичная ссылка)
#                  ./start.sh --local    (только локальный сервер)
# ============================================
set -e
cd "$(dirname "$0")"

PORT="${PORT:-3000}"

# проверки
if ! command -v node >/dev/null 2>&1; then
  echo "Ошибка: не найден node. Установи Node.js: https://nodejs.org"
  exit 1
fi

# зависимости
if [ ! -d node_modules ]; then
  echo "[*] Устанавливаю зависимости..."
  npm install --no-audit --no-fund
fi

# запуск игрового сервера
echo "[*] Запускаю сервер chill zone на порту $PORT..."
PORT="$PORT" node server.js &
SERVER_PID=$!

cleanup() {
  echo ""
  echo "[*] Останавливаю..."
  kill "$SERVER_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

sleep 1
if ! kill -0 "$SERVER_PID" 2>/dev/null; then
  echo "Ошибка: сервер не запустился."
  exit 1
fi

echo "[*] Локально: http://localhost:$PORT"

if [ "$1" = "--local" ]; then
  echo "[*] Режим без туннеля. Ctrl+C — остановить."
  wait "$SERVER_PID"
  exit 0
fi

# туннель serveo — публичная ссылка появится ниже
if ! command -v ssh >/dev/null 2>&1; then
  echo "Ошибка: не найден ssh (нужен для Serveo). Запусти с флагом --local."
  exit 1
fi

echo "[*] Поднимаю туннель Serveo... (публичная ссылка появится ниже)"
echo "    Ctrl+C — остановить всё."
echo ""
ssh -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o ServerAliveInterval=60 \
    -o ExitOnForwardFailure=yes \
    -R "80:localhost:$PORT" serveo.net
